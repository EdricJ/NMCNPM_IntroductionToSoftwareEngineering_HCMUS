<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Select PaymentPayPal or Credit CardC_078ee0</name>
   <tag></tag>
   <elementGuidId>204a271f-3f6e-484c-a587-c65d0d2c9692</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div[2]/form/select</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>select.form-select.form-select-lg.mb-3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>402a1388-91c1-4330-8dcd-d3ced2233696</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-select form-select-lg mb-3</value>
      <webElementGuid>2aa03736-ba2f-4d39-8da0-4e179d06cb0b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>.form-select-lg example</value>
      <webElementGuid>eaef7959-b6ce-46d4-ac5f-47036fea2ae7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select PaymentPayPal or Credit CardCash On Delivery</value>
      <webElementGuid>97d5a17f-80f8-4828-a004-8832d8ad8c58</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;checkout-content&quot;]/div[@class=&quot;checkout-content__left&quot;]/div[2]/form[1]/select[@class=&quot;form-select form-select-lg mb-3&quot;]</value>
      <webElementGuid>1c7edcb2-4a29-4144-baed-78caa1e1b7d6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div[2]/form/select</value>
      <webElementGuid>3a42a3b4-7bd0-4db7-9c4c-7942c2f772fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Method'])[1]/following::select[1]</value>
      <webElementGuid>c6f79e58-8beb-4d35-9a2d-e7b8550106da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Continue'])[1]/following::select[1]</value>
      <webElementGuid>ff37ef26-fdce-45b5-8b56-3eed29c0dadb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order'])[1]/preceding::select[1]</value>
      <webElementGuid>c1969bbb-bf8b-4d69-bfaa-b89159eab3f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Interesting Facts For Curious Minds'])[2]/preceding::select[1]</value>
      <webElementGuid>ce2ebb36-25a6-46de-af70-4b59b8fb2287</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>a0af81b1-9fa8-4b79-a17b-fe31b30288fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Select PaymentPayPal or Credit CardCash On Delivery' or . = 'Select PaymentPayPal or Credit CardCash On Delivery')]</value>
      <webElementGuid>fbe03402-eada-4e38-aa25-8a2c141f34e0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
