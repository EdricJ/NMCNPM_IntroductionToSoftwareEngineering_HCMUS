<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Shop now</name>
   <tag></tag>
   <elementGuidId>f3b93558-8022-4a06-b3c8-de3246e3deab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/div/div/div/div/div[3]/a/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a > button.MuiButtonBase-root.MuiButton-root.MuiButton-text.primary-btn.red > span.MuiButton-label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>799cbb29-b59d-4b53-b23e-aa1e2c05557b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiButton-label</value>
      <webElementGuid>ee7aa175-0378-4828-be53-b3ce8a55fc66</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Shop now</value>
      <webElementGuid>90116434-7790-4e36-836b-1ce110803899</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[1]/section[@class=&quot;home-banners&quot;]/div[@class=&quot;slides&quot;]/div[@class=&quot;home-banner&quot;]/div[@class=&quot;MuiContainer-root container-ui MuiContainer-maxWidthLg&quot;]/div[@class=&quot;home-banner__container&quot;]/div[3]/a[1]/button[@class=&quot;MuiButtonBase-root MuiButton-root MuiButton-text primary-btn red&quot;]/span[@class=&quot;MuiButton-label&quot;]</value>
      <webElementGuid>9abc242e-0f10-4b14-ba58-a695ac683b40</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/div/div/div/div/div[3]/a/button/span</value>
      <webElementGuid>433a4749-4b3f-4f1d-971a-10670eb7321d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Checkout'])[1]/following::span[2]</value>
      <webElementGuid>b0903ee9-3ebb-4307-bb28-0066c566126c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy more'])[1]/following::span[5]</value>
      <webElementGuid>fd513eb3-0779-4763-a462-e1fa883b2b22</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ecommerce-simplified'])[1]/preceding::span[4]</value>
      <webElementGuid>8aa902e8-d6c6-4a00-ba97-e86f0469120f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Shop now']/parent::*</value>
      <webElementGuid>40f502e9-d593-40a9-845f-e0a979b81980</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a/button/span</value>
      <webElementGuid>209e0eb3-63cd-4ca5-92db-7ff5e01237ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Shop now' or . = 'Shop now')]</value>
      <webElementGuid>94aa67fc-3c5b-47e3-b21d-2900eab0c373</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
