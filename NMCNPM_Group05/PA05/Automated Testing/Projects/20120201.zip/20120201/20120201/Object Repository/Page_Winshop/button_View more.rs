<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_View more</name>
   <tag></tag>
   <elementGuidId>12d1d34c-0454-487c-a871-4a18f743194a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/div/div[2]/button</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.btn.btn-primary.d-block.w-100</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>f115ef3f-f715-4a19-b653-daf8bc021c45</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary d-block w-100</value>
      <webElementGuid>5c29516d-0d4a-48d1-95b9-39d1bafe9993</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>View more</value>
      <webElementGuid>a925d752-b865-4fc1-9d55-40e0258bdd64</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;shop&quot;]/div[@class=&quot;MuiContainer-root MuiContainer-maxWidthLg&quot;]/div[@class=&quot;shop__container&quot;]/div[@class=&quot;shop-content&quot;]/button[@class=&quot;btn btn-primary d-block w-100&quot;]</value>
      <webElementGuid>b20bd52f-631a-491d-b6b3-32266c4805e7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/div/div[2]/button</value>
      <webElementGuid>a00053b2-b6ae-4040-964e-c90b25fd7907</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Favourite'])[9]/following::button[1]</value>
      <webElementGuid>519190fe-cfec-46e2-bc26-02edf07de66c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company'])[1]/preceding::button[1]</value>
      <webElementGuid>10ac6556-cd0d-4e51-a183-e636cd5cb1aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[1]/preceding::button[1]</value>
      <webElementGuid>27e67fdd-2d46-47f8-9ada-1f2255b54ae2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='View more']/parent::*</value>
      <webElementGuid>a8e21b48-391c-4ea2-9146-af0486b0696e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/button</value>
      <webElementGuid>9010529c-ed02-4a86-adcf-591e507782af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'View more' or . = 'View more')]</value>
      <webElementGuid>d14d2b92-3247-4162-8fab-a3dbcdbc4384</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
