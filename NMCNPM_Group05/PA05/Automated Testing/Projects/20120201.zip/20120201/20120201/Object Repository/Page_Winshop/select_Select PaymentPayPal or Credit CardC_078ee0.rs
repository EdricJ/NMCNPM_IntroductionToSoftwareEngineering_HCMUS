<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Select PaymentPayPal or Credit CardC_078ee0</name>
   <tag></tag>
   <elementGuidId>30d0c51a-6ec0-4931-91a1-fadd9922077d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div[2]/form/select</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>select.form-select.form-select-lg.mb-3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>54a40fb5-61ab-4810-aae2-e2f4cfec1402</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-select form-select-lg mb-3</value>
      <webElementGuid>d01d230b-3fab-4169-9213-0ddc9b8eecee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>.form-select-lg example</value>
      <webElementGuid>93ed9988-fd32-4e1c-8988-aa8544024183</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select PaymentPayPal or Credit CardCash On Delivery</value>
      <webElementGuid>a532a2b5-4f82-4ae6-93a9-bcf30b172928</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;checkout-content&quot;]/div[@class=&quot;checkout-content__left&quot;]/div[2]/form[1]/select[@class=&quot;form-select form-select-lg mb-3&quot;]</value>
      <webElementGuid>05c61181-c6ae-44df-8f5e-b768fdd48849</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div[2]/form/select</value>
      <webElementGuid>4d1612ec-8e5e-47b0-acb6-fff3f8d5ba45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Method'])[1]/following::select[1]</value>
      <webElementGuid>f7f7c87b-0f17-40fe-9b5c-50611977c05d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Continue'])[1]/following::select[1]</value>
      <webElementGuid>28215b74-f13f-4b5c-aa25-4df13782afcd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order'])[1]/preceding::select[1]</value>
      <webElementGuid>b1be3adf-a354-4d01-9cd5-7fb420bf2d01</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GOING ROGUE'])[2]/preceding::select[1]</value>
      <webElementGuid>ebf0d2e0-a561-4c73-bad4-7a8b753b1777</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>5d46cde8-f5db-466c-8ebc-a4afe0ae0184</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Select PaymentPayPal or Credit CardCash On Delivery' or . = 'Select PaymentPayPal or Credit CardCash On Delivery')]</value>
      <webElementGuid>eb03fbb5-2a6b-4489-8ffb-84b94bfbaa67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Interesting Facts For Curious Minds'])[2]/preceding::select[1]</value>
      <webElementGuid>062fc5fb-8098-4c68-8e7c-dbe16f836727</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
