<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Log out</name>
   <tag></tag>
   <elementGuidId>91e124c1-ac76-4540-aac3-107345e69093</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/header/div/div/div/div[2]/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.MuiButtonBase-root.MuiButton-root.MuiButton-contained.jss10.MuiButton-containedSizeSmall.MuiButton-sizeSmall.MuiButton-disableElevation > span.MuiButton-label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>177a7176-1b28-4495-b21e-c6a09d900a7a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiButton-label</value>
      <webElementGuid>e9ffac95-93ca-4118-9054-a103c5d8c5b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Log out</value>
      <webElementGuid>04767ad0-96f9-4442-aa52-51fa29aab64f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/header[@class=&quot;MuiPaper-root MuiAppBar-root MuiAppBar-positionFixed MuiAppBar-colorPrimary jss1 mui-fixed MuiPaper-elevation4&quot;]/div[@class=&quot;MuiToolbar-root MuiToolbar-regular jss3&quot;]/div[@class=&quot;jss17&quot;]/div[@class=&quot;MuiBox-root jss19&quot;]/div[@class=&quot;MuiBox-root jss21&quot;]/a[@class=&quot;MuiButtonBase-root MuiButton-root MuiButton-contained jss10 MuiButton-containedSizeSmall MuiButton-sizeSmall MuiButton-disableElevation&quot;]/span[@class=&quot;MuiButton-label&quot;]</value>
      <webElementGuid>819cca1e-7390-47e2-a589-e402ccd00b6a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/header/div/div/div/div[2]/a/span</value>
      <webElementGuid>f884abe2-b5d2-4b3a-a18f-fd985a5ed934</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shop'])[1]/following::span[2]</value>
      <webElementGuid>83150b06-4921-4f91-9d1a-2007b05c64a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::span[4]</value>
      <webElementGuid>da4d3d85-890c-4bbf-a455-216cd5bdbb5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cart'])[1]/preceding::span[5]</value>
      <webElementGuid>20ea0e0d-f6f0-4767-b6b6-ed71d32d8274</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shop'])[2]/preceding::span[5]</value>
      <webElementGuid>149b95ce-b39f-4bbc-9b27-85392dede211</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Log out']/parent::*</value>
      <webElementGuid>850d34bb-9660-4c2a-b1c5-1b53bdf1f46a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a/span</value>
      <webElementGuid>16156375-5a80-46df-8661-de23315a5fdd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Log out' or . = 'Log out')]</value>
      <webElementGuid>b73a7b8e-7197-418d-899e-f4896c9d97d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::span[2]</value>
      <webElementGuid>fb477acc-9b87-4a7f-a804-d9ab8e734786</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shop'])[1]/following::span[4]</value>
      <webElementGuid>2a7d8fd9-7b90-4118-bfb6-3385bef202df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[2]/preceding::span[5]</value>
      <webElementGuid>e9d6f679-eab3-436c-ac28-6e50a5f01c6c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
