<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Buy 5 get 40 percent off_MuiSvgIcon-root_1</name>
   <tag></tag>
   <elementGuidId>3b11f6f4-ebf9-4565-9367-8bbd2b391af5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy 5 get 40 percent off'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.MuiButtonBase-root.MuiButton-root.MuiButton-text.detail-content__btn-inc.btn-circle > span.MuiButton-label > svg.MuiSvgIcon-root</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>18df44fd-29b9-4040-a242-2d06f1119635</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiSvgIcon-root</value>
      <webElementGuid>410a28a9-34cd-4ae3-904d-1b930737d882</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>d911bdd4-d149-4eeb-998f-ea13ec4df590</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>7e42f839-d533-47cb-b36b-2c76d5083608</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>046c8278-e9a9-4911-9d96-ebe6670d5693</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;detail&quot;]/div[@class=&quot;MuiContainer-root MuiContainer-maxWidthLg&quot;]/section[@class=&quot;detail__container&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-container MuiGrid-spacing-xs-6&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-md-6&quot;]/div[@class=&quot;detail-content&quot;]/div[@class=&quot;detail-content__btns&quot;]/div[@class=&quot;detail-content__btn-handle&quot;]/button[@class=&quot;MuiButtonBase-root MuiButton-root MuiButton-text detail-content__btn-inc btn-circle&quot;]/span[@class=&quot;MuiButton-label&quot;]/svg[@class=&quot;MuiSvgIcon-root&quot;]</value>
      <webElementGuid>455ec771-bdfa-4560-858f-4394769f6d69</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy 5 get 40 percent off'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>9418fc72-1d96-4f60-984c-59d502a69b12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy 3 get 25 percent off'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>f2c90e50-2aa1-4dc3-9794-5d03aed61a67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to cart'])[1]/preceding::*[name()='svg'][3]</value>
      <webElementGuid>719200e9-6380-449f-82ba-63f454224216</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Free global shipping on all orders'])[1]/preceding::*[name()='svg'][5]</value>
      <webElementGuid>cd00db53-b48e-4462-8333-5a3145439d5f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
