<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_In Stock36_MuiSvgIcon-root</name>
   <tag></tag>
   <elementGuidId>0026769a-38bd-4439-8834-445351dcc9c0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='$14'])[1]/following::*[name()='svg'][3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.MuiButtonBase-root.MuiButton-root.MuiButton-text.cart-item__rm > span.MuiButton-label > svg.MuiSvgIcon-root</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>4776144b-a801-46ca-bc9d-4fc7b0fcc067</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiSvgIcon-root</value>
      <webElementGuid>fc7263d1-13ed-485b-9fc1-ab4fef1b1664</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>7a638313-18bf-4e01-becc-11bea3772945</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>635f52dc-9429-4d8e-adcc-80a8ec5e5f71</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>207504d5-cdfb-475e-84dc-1071648af822</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;637971fb03ca30b2d57128a9&quot;)/button[@class=&quot;MuiButtonBase-root MuiButton-root MuiButton-text cart-item__rm&quot;]/span[@class=&quot;MuiButton-label&quot;]/svg[@class=&quot;MuiSvgIcon-root&quot;]</value>
      <webElementGuid>3329abda-eab0-43ac-824a-00e250b8bb35</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$14'])[1]/following::*[name()='svg'][3]</value>
      <webElementGuid>cc39a7df-58a9-4335-935e-31a1e907fb39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Information'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>23067d3a-3537-4b1e-b28c-6eacebda79e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Discount'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>8d66eb61-66af-4ba2-9302-6e1960a32a01</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
