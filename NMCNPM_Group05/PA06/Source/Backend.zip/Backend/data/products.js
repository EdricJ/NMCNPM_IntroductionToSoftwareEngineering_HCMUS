const products = [
    {
        "id": "637050ffa6eff1b7f2738b43",
        "name": "Product 01",
        "description":"This is a sample product",
        "price": 1200,
        "image": "http://localhost:5000/public\images\products\1668445266121_Books.jpg",
        "size": "L",
        "color": "black",
        "brand":"men",
        "category":"clothes",
        "ratings":4,
        "numReviews": 1,
        "countInStock": 25,
        "user": "6370440d0bde6bf18c9838c7",
        "reviews": [
            {
             "user": "63748fe15965427d0bc60969",
             "name": "test-user 022",
                "rating": 4,
            }
        ]
    },
    {
        "id": "6370513ea6eff1b7f2738b46",
        "name": "Product 02",
        "description":"This is a sample product 02",
        "price": 2400,
        "image": "http://localhost:5000/public\images\products\1668445266121_Books.jpg",
        "size": "S",
        "color": "white",
        "brand":"women",
        "category":"clothes",
        "ratings":3,
        "numReviews": 1,
        "countInStock": 12,
        "user": "6370440d0bde6bf18c9838c7",
        "reviews": [
            {
             "user": "6373b9549b86b47b0ead31b0",
             "name": "test-user 025",
            "rating": 3,
            }
        ]
    },
    {
        "id": "6370513ea6eff1b7f2738b46",
        "name": "Product 02",
        "description":"This is a sample product 02",
        "price": 2400,
        "image": "http://localhost:5000/public\images\products\1668445266121_Books.jpg",
        "size": "S",
        "color": "white",
        "brand":"women",
        "category":"clothes",
        "ratings":3,
        "numReviews": 1,
        "countInStock": 11,
        "user": "6370440d0bde6bf18c9838c7",
        "reviews": [
            {
             "user": "6373b9549b86b47b0ead31b0",
             "name": "test-user 025",
            "rating": 3,
            }
        ]
    },
    {
        "id": "637051cff58e9aa8b4d3d8bb",
        "name": "Product 04",
        "description":"This is a sample product 04",
        "price": 1440,
        "image": "http://localhost:5000/public\images\products\1668445266121_Books.jpg",
        "size": "",
        "color": "",
        "brand":"novel",
        "category":"books",
        "ratings":3,
        "numReviews": 2,
        "countInStock": 20,
        "user": "6370440d0bde6bf18c9838c7",
        "reviews": [
            {
             "user": "6373b9549b86b47b0ead31b0",
             "name": "test-user 025",
            "rating": 3,
            },
            {
                "user": "63737f2319b56a0a46aa9e0d",
                "name": "loc85pro",
               "rating": 4,
               }
        ]
    },
    {
        "id": "637067320cafad048cae26b9",
        "name": "Product 05",
        "description":"This is a sample product 05",
        "price": 2400,
        "image": "http://localhost:5000/public\images\products\1668445266121_Books.jpg",
        "size": "",
        "color": "",
        "brand":"Horror",
        "category":"books",
        "ratings":3,
        "numReviews": 1,
        "countInStock": 15,
        "user": "63707dc82e16ab94028a3078",
        "reviews": [
            {
             "user": "6373b9549b86b47b0ead31b0",
             "name": "test-user 025",
            "rating": 3,
            }
        ]
    },
]