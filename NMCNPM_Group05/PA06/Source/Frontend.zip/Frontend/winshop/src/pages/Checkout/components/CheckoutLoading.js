import React from 'react';
import "./CheckoutLoading.scss"

function CheckoutLoading() {
  return (
    <div>Checkout Loading...</div>
  )
}

export default CheckoutLoading