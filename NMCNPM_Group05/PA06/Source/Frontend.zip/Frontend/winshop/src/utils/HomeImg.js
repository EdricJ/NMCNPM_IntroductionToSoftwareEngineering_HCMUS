import BannerOne from '../assets/images/shopping-rd.jpg';
import BannerTwo from '../assets/images/shopping-nd.jpg';
import BannerThree from '../assets/images/shopping-st.jpg';

import StepOne from '../assets/images/step-1.jpg';
import StepTwo from '../assets/images/step-2.jpg';
import StepThree from '../assets/images/step-3.jpg';
import StepFour from '../assets/images/step-4.jpg';

import ArrowOne from '../assets/images/arrow-1.png';
import ArrowTwo from '../assets/images/arrow-2.png';
import ArrowThree from '../assets/images/arrow-3.png';

import ReviewOne from '../assets/images/pic-1.png';
import ReviewTwo from '../assets/images/pic-2.png';
import ReviewThree from '../assets/images/pic-3.png';
export {
    BannerOne,
    BannerTwo,
    BannerThree,
    StepOne,
    StepTwo,
    StepThree,
    StepFour,
    ArrowOne,
    ArrowTwo,
    ArrowThree,
    ReviewOne,
    ReviewTwo,
    ReviewThree
}